package com.example.langmaster

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat

class LanguageExercises : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language_exercises)

        val textLanguage = findViewById<TextView>(R.id.textLanguage)
        val imageView = findViewById<ImageView>(R.id.exerciseImage)

        val extras = intent.extras
        if (extras != null) {
            val value = extras.getString("chosenLanguage")
            textLanguage.text = value
        }
    }
}