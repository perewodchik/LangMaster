package com.example.langmaster

class Exercise(val exerciseName: String = "Default Exercise", val imageId: Int = R.drawable.default_image) {

}